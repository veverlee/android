/** Automatically generated file. DO NOT MODIFY */
package com.example.customlayout_list;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}